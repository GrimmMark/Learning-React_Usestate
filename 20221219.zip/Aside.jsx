export const User = (props) => {
    return (
      <div>
        {props.name} {props.age}
      </div>
    );
  };